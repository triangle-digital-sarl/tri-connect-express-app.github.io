import{s as c,n as a}from"./scheduler.zdcxGOUJ.js";import{S as m,i as _,e as u,t as d,c as f,m as x,b as p,g as i,d as o}from"./index.pizW9N-D.js";function h(r){let n,s="Building Block View",e;return{c(){n=u("h1"),n.textContent=s,e=d(`


































































 -->



 -->



 -->



 -->















 -->




















 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->

 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->

















 -->



 -->



 -->

 -->











 -->



 -->


 -->

 -->


 -->

 -->`)},l(t){n=f(t,"H1",{"data-svelte-h":!0}),x(n)!=="svelte-zbbkz0"&&(n.textContent=s),e=p(t,`


































































 -->



 -->



 -->



 -->















 -->




















 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->

 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->
 -->

















 -->



 -->



 -->

 -->











 -->



 -->


 -->

 -->


 -->

 -->`)},m(t,l){i(t,n,l),i(t,e,l)},p:a,i:a,o:a,d(t){t&&(o(n),o(e))}}}class B extends m{constructor(n){super(),_(this,n,null,h,c,{})}}export{B as default};
