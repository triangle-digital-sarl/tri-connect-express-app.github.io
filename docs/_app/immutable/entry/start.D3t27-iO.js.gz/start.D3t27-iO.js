import{b as a}from"../chunks/entry.BPgSMXMc.js";export{a as start};
