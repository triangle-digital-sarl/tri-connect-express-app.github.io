import{b as a}from"../chunks/entry.Bu9Rnk1S.js";export{a as start};
