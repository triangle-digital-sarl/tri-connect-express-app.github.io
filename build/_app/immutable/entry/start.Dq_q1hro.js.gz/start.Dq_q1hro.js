import{b as a}from"../chunks/entry.Db2HRIoI.js";export{a as start};
